<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();
isAdmin();


include 'menu.php';

ob_end_flush();


//Liste des utilisateurs sans l'utilisateur connecté

$utilisateurs_req = $bdd->prepare('SELECT * FROM users WHERE id_user != :id_user');
$utilisateurs_req->execute(['id_user' => $_SESSION['id_user']]);
$utilisateurs = $utilisateurs_req->fetchAll();

// Liste des personnages non valide

$personnages_req = $bdd->query('SELECT * FROM personnage WHERE valide = 1');
$personnages = $personnages_req->fetchAll();

// Liste des equipements non valide

$equipements_req = $bdd->query('SELECT * FROM equipement WHERE valide = 1');
$equipements = $equipements_req->fetchAll();

// Liste des types non valide

$type_req = $bdd->query('SELECT * FROM type where valide = 1');
$types = $type_req->fetchAll();

?>


<h1>Table des Utilisateurs <h1>
        <table class="table">
            <thead>
                <tr>

                    <th>Nom</th>
                    <th>Pseudo</th>
                    <th> Nombre de Combat réalisées</th>
                    <th> Actions </th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($utilisateurs as $utilisateur) {
                    ?>
                    <tr>
                        <td>
                            <?= $utilisateur['nom'] ?>
                        </td>
                        <td>
                            <?= $utilisateur['pseudonyme'] ?>
                        </td>
                        <td>
                            <?php
                            $combat_Rq = $bdd->prepare('SELECT COUNT(*) FROM combat LEFT JOIN users ON combat.id_user_combattant = users.id_user WHERE id_user_combattant = ?');
                            $combat_Rq->execute([$utilisateur['id_user']]);
                            $combat = $combat_Rq->fetch();
                            ?>
                            <?= $combat[0] ?>
                        </td>



                        <td>
                            <a class="link-dark" href="fiche_user.php?id_user=<?= $utilisateur['id_user'] ?>">
                                Detail de l'utilisateur
                            </a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>

        </table>

        <h1> Listes des personnages non valide</h1>
        <table class="table">
            <thead>
                <tr>

                    <th>Nom</th>
                    <th>Stats</th>
                    <th> Actions </th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($personnages as $personnage) {
                    ?>
                    <tr>
                        <td>
                            <?= $personnage['nom_personnage'] ?>
                        </td>
                        <td>
                            <?= $personnage['stats'] ?>
                        </td>
                        <td>
                            <a class="link-dark" href="fiche.php?id_personnage=<?php echo $personnage['id_personnage']; ?>">
                                Detail du personnage
                            </a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
        <h1> Liste des equipement non valide</h1>
        <table class="table">
            <thead>
                <tr>

                    <th>Nom</th>
                    <th> Bonus</th>
                    <th> Actions </th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($equipements as $equipement) {
                    ?>
                    <tr>
                        <td>
                            <?= $equipement['nom_equipement'] ?>
                        </td>
                        <td>
                            <?= $equipement['bonus'] ?>
                        </td>
                        <td>
                            <a class="link-dark"
                                href="fiche_equipement.php?id_equipement=<?php echo $equipement['id_equipement']; ?>">
                                Detail de l'equipement
                            </a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>

        <h1> Liste des types non valide</h1>
        <table class="table">
            <thead>
                <tr>

                    <th>Nom</th>
                    <th> Actions </th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($types as $type) {
                    ?>
                    <tr>
                        <td>
                            <?= $type['nom'] ?>
                        </td>
                        <td>
                            <a class="link-dark" href="fiche_type.php?id_type=<?php echo $type['id_type']; ?>">
                                Detail du type
                            </a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>



        <?php include 'footer.php' ?>