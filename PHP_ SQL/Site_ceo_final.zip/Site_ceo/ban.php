<?php
include 'header.php';
header("refresh:3;url=deconnexion.php");
?>

<h1>Vous avez été banni, vous allez être redirigé vers la page de connexion</h1>

<?php include 'footer.php' ?>