<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();



include 'menu.php';



$personnage_req = $bdd->query('SELECT * FROM personnage WHERE valide = 0');
$personnages = $personnage_req->fetchAll();


$equipement_req = $bdd->query('SELECT * FROM equipement WHERE valide = 0');
$equipements = $equipement_req->fetchAll();

$id_selection1 = null;
$id_equipement_sel1 = null;
$id_selection2 = null;
$id_equipement_sel2 = null;



if (isset($_POST["submit"])) {

    $personnage1 = $_POST['id_personnage_select'];
    $equipement1 = $_POST['id_equipement_select'];
    for ($i = 0; $i < count($personnages); $i++) {
        if ($personnages[$i]['id_personnage'] == $personnage1) {
            $personnage_test = $personnages[$i];
        }
    }
    for ($i = 0; $i < count($equipements); $i++) {
        if ($equipements[$i]['id_equipement'] == $equipement1) {
            $equipement_test = $equipements[$i];
        }
    }

    if ($personnage_test['id_type_personnage'] == $equipement_test['id_type_equipement']) {
        $stats_test = $personnage_test['stats'] + $equipement_test['bonus'];
    } else {
        $stats_test = $personnage_test['stats'];
    }


    // le personnage adverse


    $personnage2 = $_POST['id_personnage_select2'];
    $equipement2 = $_POST['id_equipement_select2'];
    for ($i = 0; $i < count($personnages); $i++) {
        if ($personnages[$i]['id_personnage'] == $personnage2) {
            $personnage_test2 = $personnages[$i];
        }
    }
    for ($i = 0; $i < count($equipements); $i++) {
        if ($equipements[$i]['id_equipement'] == $equipement2) {
            $equipement_test2 = $equipements[$i];
        }
    }
    if ($personnage_test2['id_type_personnage'] == $equipement_test2['id_type_equipement']) {
        $stats2 = $personnage_test2['stats'] + $equipement_test2['bonus'];
    } else {
        $stats2 = $personnage_test2['stats'];
    }


    // resulatat du combat

    if ($stats_test > $stats2) {
        $_SESSION['id_winner'] = $personnage_test['id_personnage']; // le gagnant
        $_SESSION['id_winner_w'] = $personnage_test['id_personnage'];
        $_SESSION['id_equipement_winner'] = $equipement_test['id_equipement']; // l'equipement du gagnant
        $_SESSION['stats_winner'] = $stats_test; // les stats du gagnant

        $_SESSION['id_looser'] = $personnage_test2['id_personnage']; //le perdant
        $_SESSION['id_equipement_looser'] = $equipement_test2['id_equipement']; //l'equipement du perdant
        $_SESSION['stats_looser'] = $stats2; //les stats du perdant
        header('Location: win1.php');
        die;
    } else if ($stats_test == $stats2) {
        header('Location: draw.php');
        die;
    } else {
        // on switch les winners et les loosers
        $_SESSION['id_winner'] = $personnage_test2['id_personnage'];
        $_SESSION['id_equipement_winner'] = $equipement_test2['id_equipement'];
        $_SESSION['stats_winner'] = $stats2;

        $_SESSION['id_looser'] = $personnage_test['id_personnage'];
        $_SESSION['id_equipement_looser'] = $equipement_test['id_equipement'];
        $_SESSION['stats_looser'] = $stats_test;

        header('Location: win2.php');
        die;
    }
}
ob_end_flush();
?>

<br>
<section id="combat">
    <div class="container-lg">
        <div class="text-center">
            <h1>C'est l'heure du Combat</h1>
            <p class="lead">... Choisissez votre personnage et votre équipement et votre adversaire...</p>
        </div>


        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form method="post" enctype="multipart/form-data">
                    <div>
                        <h2>Personnage Utilisateur</h2>
                        <label for="nom_personnage" class="form-label">Nom Personnage *</label>
                        <select class="form-control" name="id_personnage_select" required>
                            <option value=""></option>
                            <?php
                            foreach ($personnages as $personnage) {
                                $id_selection1 = $personnage['id_personnage'];
                                ?>
                                <option value="<?= $id_selection1 ?>">
                                    <?= $personnage['nom_personnage'] ?>
                                </option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="Equipement" class="form-label">Equipement Personnage </label>
                        <select name="id_equipement_select" class="form-control" required>
                            <option value=""></option>
                            <?php
                            foreach ($equipements as $equipement) {
                                $id_equipement_sel1 = $equipement['id_equipement'];
                                ?>
                                <option value="<?= $id_equipement_sel1 ?>">
                                    <?= $equipement['nom_equipement'] ?>
                                </option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <br>
                    <br>
                    <h2>Personnage Adverse</h2>
                    <label for="nom_personnage" class="form-label">Nom Personnage *</label>
                    <select name="id_personnage_select2" class="form-control" required>
                        <option value=""></option>
                        <?php
                        foreach ($personnages as $personnage) {
                            $id_selection2 = $personnage['id_personnage'];
                            ?>
                            <option value="<?= $id_selection2 ?>">
                                <?= $personnage['nom_personnage'] ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
                    <label for="Equipement" class="form-label">Equipement Personnage </label>
                    <select name="id_equipement_select2" class="form-control" required>
                        <option value=""></option>
                        <?php
                        foreach ($equipements as $equipement) {
                            $id_equipement_sel2 = $equipement['id_equipement'];
                            ?>
                            <option value="<?= $id_equipement_sel2 ?>">
                                <?= $equipement['nom_equipement'] ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
            </div>

            <div class="mb-4 text-center">
                <input type="submit" class="btn btn-outline-dark" name="submit" value="Selectionner">
            </div>
            </form>

        </div>
    </div>

</section>


<?php
include 'footer.php';
?>