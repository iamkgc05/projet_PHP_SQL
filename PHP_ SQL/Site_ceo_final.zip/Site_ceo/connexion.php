<?php
require('header.php');
if (isset($_POST['connexion'])) {
    $pseudo = htmlspecialchars($_POST['pseudonyme']);
    $mdp = sha1($_POST['mots_de_passe']);

    $selRq = $bdd->prepare('SELECT * from users WHERE pseudonyme = ? AND mots_de_passe = ?');
    $selRq->execute(array($pseudo, $mdp));
    if ($selRq->rowCount() > 0) {
        $users = $selRq->fetch();
        $_SESSION['id_user'] = $users['id_user'];
        $_SESSION['pseudonyme'] = $users['pseudonyme'];
        $_SESSION['mots_de_passe'] = $users['mots_de_passe'];
        $_SESSION['admin'] = $users['admin'];
        $_SESSION['ban'] = $users['ban'];
        if ($_SESSION['ban'] == 0) {
            header('Location: test.php');
            die;

        } else {
            header('Location: ban.php');
            die;
        }


    } else {
        echo "Le pseudonyme ou le mot de passe est incorrect";
    }
}
?>




<section id="signin">
    <div class="container-lg">

        <div class="text-center">
            <h1> Connectez-vous</h1>
            <p class="lead">...Et c'est parti !!!</p>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form action="" method="POST">
                    <div>
                        <label for="pseudo" class="form-label">Pseudo</label>
                        <input class="form-control" type="text" name="pseudonyme" required>
                    </div>
                    <div>
                        <label for="mots_de_passe" class="form-label">Mot de passe</label>
                        <input class="form-control" type="password" name="mots_de_passe" required>
                    </div>
                    <br>
                    <div class="mb-4 text-center">
                        <input class="btn btn-outline-dark" type="submit" name="connexion" value="Se connecter">
                    </div>
                    <div class="mb-4 text-center">
                        <a href="signup.php">Pas de compte? Cree en un ici </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require('footer.php'); ?>