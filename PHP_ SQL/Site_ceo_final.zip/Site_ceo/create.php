<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();


include 'menu.php';



if (isset($_POST['create'])) {
    $nom_personnage = htmlspecialchars($_POST['nom_personnage']);
    $stats = htmlspecialchars($_POST['stats']);
    $id_type_personnage = htmlspecialchars($_POST['id_type_personnage']);
    $description = htmlspecialchars($_POST['description']);

    $profile_img = null;
    if (isset($_FILES["imagefile"])) {
        $profile_img = "images/" . $_FILES["imagefile"]["name"];
        move_uploaded_file($_FILES["imagefile"]["tmp_name"], $profile_img);
    }

    $insert = $bdd->prepare('INSERT INTO personnage(nom_personnage, stats, id_type_personnage, profil, description) VALUES(:nom_personnage, :stats, :id_type_personnage, :profil, :description)');
    $insert->execute(
        array(
            'nom_personnage' => $nom_personnage,
            'stats' => $stats,
            'id_type_personnage' => $id_type_personnage,
            'profil' => $profile_img,
            'description' => $description
        )
    );
    header('Location:index.php');
    die;
}
ob_end_flush();

?>
<section id="create">
    <div class="container-lg">

        <div class="text-center">
            <h1> Nous allons creer votre personnage</h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form method="post" enctype="multipart/form-data">
                    <div>
                        <label class="form-label" for="nom_personnage">Nom*</label>
                        <input class="form-control" type="text" id="nom_personnage" name="nom_personnage" required>
                    </div>
                    <div>
                        <label class="form-label" for="stats">Statistique*</label>
                        <input class="form-control" type="number" id="stats" name="stats" min="0" required>
                    </div>
                    <div>
                        <label class="form-label" for="id_type_personnage">Type*</label>
                        <select class="form-control" name="id_type_personnage" id="id_type_personnage">
                            <option value=""></option>
                            <?php
                            $type_req = $bdd->query('SELECT * FROM type WHERE valide = 0 ORDER BY type.nom');
                            $types = $type_req->fetchAll();
                            foreach ($types as $type) {
                                ?>
                                <option value="<?= $type['id_type'] ?>">
                                    <?= $type['nom'] ?>
                                </option>
                                <?php
                            }
                            ?>
                        </select>

                    </div>
                    <div>
                        <label class="form-label" for="profil">Photo de profil</label><br />
                        <input class="form-control" type="file" name="imagefile"><br />
                    </div>
                    <div>
                        <label class="form-label" for="description">Description</label>
                        <textarea class="form-control" name="description" id="description" cols="30"
                            rows="10"></textarea>
                    </div>
                    <br>
                    <div class="mb-4 text-center">
                        <input type="submit" name="create" value="Soumettre">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
</div>

<?php
include 'footer.php';
?>