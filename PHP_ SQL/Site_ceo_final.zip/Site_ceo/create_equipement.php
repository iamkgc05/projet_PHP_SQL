<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();

include 'menu.php';


if (isset($_POST['create'])) {
    $nom_equipement = htmlspecialchars($_POST['nom_equipement']);
    $bonus = htmlspecialchars($_POST['bonus']);
    $id_type_equipement = htmlspecialchars($_POST['id_type_equipement']);

    $profile_img = null;
    if (isset($_FILES["imagefile"])) {
        $profile_img = "images/" . $_FILES["imagefile"]["name"];
        move_uploaded_file($_FILES["imagefile"]["tmp_name"], $profile_img);
    }

    $insert = $bdd->prepare('INSERT INTO equipement(nom_equipement, bonus, id_type_equipement, profil) VALUES(:nom_equipement, :bonus, :id_type_equipement, :profil)');
    $insert->execute(
        array(
            'nom_equipement' => $nom_equipement,
            'bonus' => $bonus,
            'id_type_equipement' => $id_type_equipement,
            'profil' => $profile_img
        )
    );
    header("Location:validation.php");
    die;
}

ob_end_flush();
?>

<section id="equipement">
    <div class="container-lg">

        <div class="text-center">
            <h1> Nous allons creer votre equipement</h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form method="post" enctype="multipart/form-data">
                    <div>
                        <label class="form-label" for="nom_equipement">Nom*</label>
                        <input class="form-control" type="text" id="nom_equipement" name="nom_equipement" required>
                    </div>
                    <div>
                        <label class="form-label" for="bonus">Bonus*</label>
                        <input class="form-control" type="number" id="bonus" name="bonus" min="0" max="1000" required>
                    </div>
                    <div>
                        <label class="form-label" for="id_type_equipement">Type*</label>
                        <select class="form-control" name="id_type_equipement" id="id_type_equipement" required>
                            <option value=""></option>
                            <?php
                            $type_req = $bdd->query('SELECT * FROM type WHERE valide = 0 ORDER BY type.nom');
                            $types = $type_req->fetchAll();
                            foreach ($types as $type) {
                                ?>
                                <option value="<?= $type['id_type'] ?>">
                                    <?= $type['nom'] ?>
                                </option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label" for="imagefile">Image de profil</label>
                        <input class="form-control" type="file" name="imagefile"><br />
                    </div>
                    <div class="mb-4 text-center">
                        <input type="submit" name="create" value="Créer">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php
include 'footer.php';
?>