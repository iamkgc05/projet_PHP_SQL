<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();


include 'menu.php';



if (isset($_POST['creation'])) {
    $nom = htmlspecialchars($_POST['nom']);
    $req = $bdd->prepare('INSERT INTO type(nom) VALUES (:nom)');
    $req->execute(array(
        'nom' => $nom
    ));
    header('Location: validation.php');
    die;
}

ob_end_flush();

?>
<section id="type">
    <div class="container-lg">

        <div class="text-center">
            <h1> Nous allons creer un nouveau type </h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form action="" method="post">
                    <label for="nom" class="form-label">Nom du type</label>
                    <input type="text" name="nom" id="nom" class="form-control" required>
                    <br>
                    <div class="mb-4 text-center">
                        <input type="submit" name='creation' class="btn btn-outline-dark" value="Créer">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>




<?php include 'footer.php' ?>