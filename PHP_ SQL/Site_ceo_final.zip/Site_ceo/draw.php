<?php
include 'header.php';
include 'function.php';
isUserConnected();
isBan();
header("refresh:3;url=combat.php");
?>
<!-- En cas d'égalité de stats -->

<h1>Aucun gagnant aucune mis à jour de victoire et aucun ajout dans combat </h1>

<?php include 'footer.php' ?>