<?php
include 'header.php';

ob_start();
include 'function.php';
isUserConnected();
isBan();
isAdmin();
include 'menu.php';




if (!isset($_GET['id_personnage'])) {
    header('Location:index.php');
    die;
}

$infoPersonnage = $bdd->prepare('SELECT * FROM personnage WHERE id_personnage = ?');
$infoPersonnage->execute([$_GET['id_personnage']]);
if ($infoPersonnage->rowCount() == 0) {
    header('Location:index.php');
    die;
}
$personnage = $infoPersonnage->fetch();

if (isset($_POST['modifier'])) {
    $nom = $_POST['nom'];
    $type_personnage = $_POST['type_personnage'];
    $stats = $_POST['stats'];
    $description = $_POST['description'];


    $profil = $personnage['profil'];
    $profile_img = null;
    if (isset($_FILES["imagefile"]) && $_FILES["imagefile"]["name"] != "" && $_FILES["imagefile"]["size"] > 0 && $_FILES["imagefile"]["size"] < 1000000) {
        $profile_img = "images/" . $_FILES["imagefile"]["name"];
        move_uploaded_file($_FILES["imagefile"]["tmp_name"], $profile_img);
    }
    if ($profile_img != null) {
        $profil = $profile_img;
    }

    $valide = $_POST['valide'];

    $modifPersonnage = $bdd->prepare('UPDATE personnage SET `nom_personnage` = ?, `id_type_personnage` = ?, `stats` = ?, `profil` = ?, `description` = ?, `valide` = ? WHERE `id_personnage` = ?');
    $modifPersonnage->execute([$nom, $type_personnage, $stats, $profil, $description, $valide, $_GET['id_personnage']]);
    header('Location:fiche.php?id_personnage=' . $_GET['id_personnage']);
    die;

}
ob_end_flush();
?>

<section id="edit_perso">
    <div class="container-lg">

        <div class="text-center">
            <h1>Modification du personnage</h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">

                <form action="" method="post" enctype="multipart/form-data">
                    <div>
                        <label for="" class="form-label">Profil</label>
                        <input class="form-control" type="file" name="imagefile"><br />
                    </div>
                    <div>
                        <label for="" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" value="<?= $personnage['nom_personnage'] ?>"
                            required>
                    </div>
                    <div>
                        <label for="" class="form-label">Type de personnage</label>
                        <p><b>Actuel:</b>
                            <?php
                            $type_req = $bdd->prepare('SELECT * FROM type LEFT JOIN personnage ON type.id_type = personnage.id_type_personnage WHERE id_type = ?');
                            $type_req->execute([$personnage['id_type_personnage']]);
                            $type = $type_req->fetch();
                            ?>
                            <?= $type['nom'] ?>
                        </p>
                        <label class="form-label">Changer pour:</label>
                        <select class="form-control" name="type_personnage" id="">
                            <?php
                            $type_req = $bdd->query('SELECT * FROM type WHERE valide = 0 ORDER BY type.nom');
                            $types = $type_req->fetchAll();
                            foreach ($types as $type) {
                                ?>
                                <option value="<?= $type['id_type'] ?>">
                                    <?= $type['nom'] ?>
                                </option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="" class="form-label">Stats</label>
                        <input class="form-control" type="number" name="stats" min="0" max="9999"
                            value="<?= $personnage['stats'] ?>" required>
                    </div>
                    <div>
                        <label for="" class="form-label">Description</label>
                        <input class="form-control" type="text" name="description"
                            value="<?= $personnage['description'] ?>">
                    </div>

                    <div>
                        <label for="" class="form-label">Validez ?</label>
                        <input class="form-control" type="number" name="valide" value="<?= $personnage['valide'] ?>"
                            min="0" max="1" required>
                    </div>

                    <br>
                    <div class="mb-4 text-center">
                        <button type="submit" name="modifier" class="btn btn-outline-dark">Modifier</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php
include 'footer.php';
?>