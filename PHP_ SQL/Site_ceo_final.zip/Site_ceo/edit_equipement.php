<?php
include 'header.php';

ob_start();
include 'function.php';
isUserConnected();
isBan();
isAdmin();
include 'menu.php';




if (!isset($_GET['id_equipement'])) {
    header('Location:index.php');
    die;
}

$equipement_req = $bdd->prepare('SELECT * FROM equipement WHERE equipement.id_equipement = :id');
$equipement_req->execute(['id' => $_GET['id_equipement']]);
if ($equipement_req->rowCount() === 0) {
    header('Location:index.php');
    die;
}
$equipement = $equipement_req->fetch();

if (isset($_POST['modifier'])) {
    $profil = $equipement['profil'];
    $profile_img = null;
    if (isset($_FILES["imagefile"]) && $_FILES["imagefile"]["name"] != "" && $_FILES["imagefile"]["size"] > 0 && $_FILES["imagefile"]["size"] < 1000000) {
        $profile_img = "images/" . $_FILES["imagefile"]["name"];
        move_uploaded_file($_FILES["imagefile"]["tmp_name"], $profile_img);
    }
    if ($profile_img != null) {
        $profil = $profile_img;
    }

    $nom = htmlspecialchars($_POST['nom']);
    $type = htmlspecialchars($_POST['type']);
    $bonus = htmlspecialchars($_POST['bonus']);
    $valide = htmlspecialchars($_POST['valide']);

    $modifEquipement = $bdd->prepare('UPDATE equipement SET `nom_equipement` = ?, `id_type_equipement` = ?, `bonus` = ?, `profil` = ?, `valide` = ? WHERE `id_equipement` = ?');
    $modifEquipement->execute([$nom, $type, $bonus, $profil, $valide, $_GET['id_equipement']]);
    header('Location:fiche_equipement.php?id_equipement=' . $_GET['id_equipement']);
    die;


}
ob_end_flush();
?>

<section id="edit_equipement">
    <div class="container-lg">

        <div class="text-center">
            <h1> Fiche de l'équipement </h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">

                <form action="" method="post" enctype="multipart/form-data">
                    <div>
                        <label for="" class="form-label">Profil</label>
                        <input class="form-control" type="file" name="imagefile"><br />
                    </div>
                    <div>
                        <label for="" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" value="<?= $equipement['nom_equipement'] ?>"
                            required>
                    </div>
                    <br>
                    <div>
                        <label for="" class="form-label">Type de l'equipement</label>
                        <p><b>Actuel:</b>
                            <?php
                            $type_req = $bdd->prepare('SELECT * FROM type LEFT JOIN equipement ON type.id_type = equipement.id_type_equipement WHERE id_type = ? AND equipement.valide = 0');
                            $type_req->execute([$equipement['id_type_equipement']]);
                            $type = $type_req->fetch();
                            ?>
                            <?= $type['nom'] ?>
                        </p>
                        <label class="form-label">Changer pour:</label>
                        <select class="form-control" name="type" id="">
                            <?php
                            $type_req = $bdd->query('SELECT * FROM type WHERE valide = 0 ORDER BY type.nom');
                            $types = $type_req->fetchAll();
                            foreach ($types as $type) {
                                ?>
                                <option value="<?= $type['id_type'] ?>">
                                    <?= $type['nom'] ?>
                                </option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="" class="form-label">Bonus</label>
                        <input class="form-control" type="number" name="bonus" value="<?= $equipement['bonus'] ?>"
                            min="-1000" max="1000" required>
                    </div>

                    <div>
                        <label for="" class="form-label">Valide</label>
                        <input class="form-control" type="number" name="valide" value="<?= $equipement['valide'] ?>"
                            min="0" max="1" required>
                    </div>
                    <br>
                    <div class="mb-4 text-center">
                        <input class="btn btn-outline-dark" type="submit" name="modifier" value="Modifier">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>