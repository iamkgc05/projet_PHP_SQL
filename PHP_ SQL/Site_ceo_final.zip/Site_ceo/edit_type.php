<?php


//Page pour admin et seulement si il est connecté
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();
isAdmin();

include 'menu.php';


if (!isset($_GET['id_type'])) {
    header('Location:index.php');
    die;
}

$type_req = $bdd->prepare('SELECT * FROM type WHERE type.id_type = :id');
$type_req->execute(['id' => $_GET['id_type']]);
if ($type_req->rowCount() === 0) {
    header('Location:index.php');
    die;
}
$type = $type_req->fetch();

if (isset($_POST['modifier'])) {
    $req = $bdd->prepare('UPDATE type SET nom = :nom, valide = :valide WHERE id_type = :id');
    $req->execute([
        'nom' => $_POST['nom'],
        'valide' => $_POST['valide'],
        'id' => $_GET['id_type']
    ]);
    header('Location:index.php');
    die;
}
ob_end_flush();

?>



<section id="edit_type">
    <div class="container-lg">

        <div class="text-center">
            <h1> Fiche du type </h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form action="" method="post">
                    <div>
                        <label for="" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" value="<?= $type['nom'] ?>" required>
                    </div>
                    <div>
                        <label for="" class="form-label">Valide</label>
                        <input class="form-control" type="number" name="valide" value="<?= $type['valide'] ?>" min="0"
                            max="1" required>
                    </div>
                    <br>
                    <div class="mb-4 text-center">
                        <input class="btn btn-outline-dark" type="submit" name="modifier" value="Modifier">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php' ?>