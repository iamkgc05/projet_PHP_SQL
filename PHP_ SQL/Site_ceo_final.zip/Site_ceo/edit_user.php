<?php
include 'header.php';
ob_start();
include 'function.php';
isUserConnected();

if ($_SESSION['id_user'] != $_GET['id_user']) {
    isAdmin();

}
isBan();

include 'menu.php';







// je verifie si l'utilisateur est admin ou si il est sur sa propre fiche



if (!isset($_GET['id_user'])) {
    header('Location:index.php');
    die;
}

$infoUser = $bdd->prepare('SELECT * FROM users WHERE id_user = ?');
$infoUser->execute([$_GET['id_user']]);
if ($infoUser->rowCount() == 0) {
    header('Location:index.php');
    die;
}

$user = $infoUser->fetch();

if (isset($_POST['modifier'])) {
    if ($_GET['id_user'] == $_SESSION['id_user']) {
        $req = $bdd->prepare('UPDATE users SET nom = :nom, pseudonyme = :pseudonyme WHERE id_user = :id');
        $req->execute([
            'nom' => $_POST['nom'],
            'pseudonyme' => $_POST['pseudonyme'],
            'id' => $_GET['id_user']
        ]);
        header('Location:fiche_user.php?id_user=' . $_GET['id_user']);
        die;
    }

    $admin = $_POST['admin'];
    $ban = $_POST['ban'];

    $modifUser = $bdd->prepare('UPDATE users SET `admin` = ?, `ban` = ? WHERE `id_user` = ?');
    $modifUser->execute([$admin, $ban, $_GET['id_user']]);
    header('Location:fiche_user.php?id_user=' . $_GET['id_user']);
    die;
}
ob_end_flush();

?>

<section id="edit_type">
    <div class="container-lg">

        <div class="text-center">


            <h1>Modification de l'utilisateur</h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form action="" method="post">
                    <?php
                    if ($_GET['id_user'] == $_SESSION['id_user']) {
                        ?>
                        <div>
                            <label for="" class="form-label">Nom</label>
                            <input class="form-control" type="text" name="nom" value="<?= $user['nom'] ?>" required>
                        </div>
                        <div>
                            <label for="" class="form-label">Pseudo</label>
                            <input class="form-control" type="text" name="pseudonyme" value="<?= $user['pseudonyme'] ?>"
                                required>
                        </div>
                        <?php
                    } else {
                        ?>

                        <div>
                            <label for="" class="form-label">Nom</label>
                            <input class="form-control" type="text" name="nom" value="<?= $user['nom'] ?>" disabled>
                        </div>
                        <div>
                            <label for="" class="form-label">Pseudo</label>
                            <input class="form-control" type="text" name="pseudonyme" value="<?= $user['pseudonyme'] ?>"
                                disabled>
                        </div>
                        <?php
                    }
                    ?>

                    <div>
                        <label for="" class="form-label">Nombre de Combat </label>
                        <?php
                        $combat_Rq = $bdd->prepare('SELECT COUNT(*) FROM combat LEFT JOIN users ON combat.id_user_combattant = users.id_user WHERE id_user_combattant = ?');
                        $combat_Rq->execute([$user['id_user']]);
                        $combat = $combat_Rq->fetch();
                        ?>
                        <input class="form-control" type="number" name="combat" value="<?= $combat[0] ?>" disabled>
                    </div>


                    <?php
                    if ($_SESSION['admin'] != 1 || $_SESSION['id_user'] == $_GET['id_user']) {
                        ?>
                        <div>
                            <label for="" class="form-label">Admin</label>
                            <input class="form-control" type="number" name="admin" value="<?= $user['admin'] ?>" min="0"
                                max="1" disabled>
                        </div>
                        <div>
                            <label for="" class="form-label">Ban</label>
                            <input class="form-control" type="number" name="ban" value="<?= $user['ban'] ?>" min="0" max="1"
                                disabled>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div>
                            <label for="" class="form-label">Admin</label>
                            <input class="form-control" type="number" name="admin" value="<?= $user['admin'] ?>" min="0"
                                max="1" required>
                        </div>
                        <div>
                            <label for="" class="form-label">Ban</label>
                            <input class="form-control" type="number" name="ban" value="<?= $user['ban'] ?>" min="0" max="1"
                                required>
                        </div>
                        <?php
                    }
                    ?>
                    <br>
                    <div class="mb-4 text-center">
                        <input class="btn btn-outline-dark" type="submit" name="modifier" value="Modifier">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>



<?php include 'footer.php' ?>