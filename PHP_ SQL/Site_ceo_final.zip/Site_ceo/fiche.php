<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();



include 'menu.php';


if (!isset($_GET['id_personnage'])) {
    header('Location:index.php');
    die;
}


$perso_req = $bdd->prepare('SELECT * FROM personnage WHERE personnage.id_personnage = :id');
$perso_req->execute(['id' => $_GET['id_personnage']]);
if ($perso_req->rowCount() === 0) {
    header('Location:index.php');
    die;
}

$perso = $perso_req->fetch();

$win_req = $bdd->prepare('SELECT SUM(win) AS win FROM combattant LEFT JOIN personnage ON combattant.id_personnage_combattant = personnage.id_personnage WHERE personnage.id_personnage = ?');
$win_req->execute([$perso['id_personnage']]);
$win = $win_req->fetch();
ob_end_flush();
?>

<section id="Fiche">
    <div class="container-lg">
        <div class="text-center">
            <h1> Fiche du Héros</h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">

                <form action="" method="post">
                    <div><label class="form-label"><b><U>Profil:</U></b></label>
                        <img class="form-control" src="<?= $perso['profil'] ?>" alt="<?= $perso['profil'] ?>" width=40%
                            height=50%>
                    </div>
                    <div>
                        <label for="" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" value="<?= $perso['nom_personnage'] ?>"
                            disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Type de personnage</label>
                        <?php
                        $type_req = $bdd->prepare('SELECT * FROM type LEFT JOIN personnage ON type.id_type = personnage.id_type_personnage WHERE id_type = ?');
                        $type_req->execute([$perso['id_type_personnage']]);
                        $type = $type_req->fetch();
                        ?>
                        <input class="form-control" type="text" name="type_personnage" id="type_personnage"
                            value="<?= $type['nom'] ?>" disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Stats</label>
                        <input class="form-control" type="text" name="stats" id="stats" value="<?= $perso['stats'] ?>"
                            disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Win</label>
                        <input class="form-control" type="text" name="win" id="win" value="<?= $win['win'] ?>" disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Description</label>
                        <input class="form-control" type="text" name="description" id="description"
                            value="<?= $perso['description'] ?>" disabled>
                    </div>

                    <?php
                    if ($_SESSION['admin'] == 1) {
                        ?>
                        <div>
                            <label for="" class="form-label">Valide</label>
                            <input class="form-control" type="text" name="valide" id="valide"
                                value="<?= $perso['valide'] ?>" disabled>
                        </div>
                        <br>
                        <div class="mb-4 text-center">
                            <a href="edit.php?id_personnage=<?= $_GET['id_personnage'] ?>" class="btn btn-outline-dark">
                                Modifier la Fiche</a>
                        </div>
                        <?php
                    }
                    ?>

                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php' ?>