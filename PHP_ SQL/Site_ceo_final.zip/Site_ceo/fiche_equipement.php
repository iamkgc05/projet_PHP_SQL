<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();


include 'menu.php';


if (!isset($_GET['id_equipement'])) {
    header('Location:index.php');
    die;
}

$equipement_req = $bdd->prepare('SELECT * FROM equipement WHERE equipement.id_equipement = :id');
$equipement_req->execute(['id' => $_GET['id_equipement']]);
if ($equipement_req->rowCount() === 0) {
    header('Location:index.php');
    die;
}
$equipement = $equipement_req->fetch();

ob_end_flush();
?>
<section id="fiche_type">
    <div class="container-lg">

        <div class="text-center">

            <h1> Fiche de l'équipement </h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">


                <form action="" method="post">
                    <div class="form-label"><b><U>Profil:</U></b>
                        <img class="form-control" src="<?= $equipement['profil'] ?>" alt="<?= $equipement['profil'] ?>"
                            width=40% height=50%>
                    </div>
                    <div>
                        <label for="" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" value="<?= $equipement['nom_equipement'] ?>"
                            disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Type d'équipement</label>
                        <?php
                        $type_req = $bdd->prepare('SELECT * FROM type LEFT JOIN equipement ON type.id_type = equipement.id_type_equipement WHERE id_type_equipement = ?');
                        $type_req->execute([$equipement['id_type_equipement']]);
                        $type = $type_req->fetch();
                        ?>
                        <input class="form-control" type="text" name="type" value="<?= $type['nom'] ?>" disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Bonus</label>
                        <input class="form-control" type="text" name="bonus" value="<?= $equipement['bonus'] ?>"
                            disabled>
                    </div>

                    <!-- verification admin pour modifier la fiche -->
                    <?php
                    if ($_SESSION['admin'] == 1) {
                        ?>
                        <div>
                            <label for="" class="form-label">Valide</label>
                            <input class="form-control" type="text" name="valide" value="<?= $equipement['valide'] ?>"
                                disabled>
                        </div>
                        <br>
                        <div class="mb-4 text-center">
                            <a href="edit_equipement.php?id_equipement=<?= $_GET['id_equipement'] ?>"
                                class="btn btn-outline-dark"> Modifier
                                l'equipement</a>
                        </div>
                        <?php
                    }
                    ?>
                </form>
            </div>
        </div>
    </div>
</section>


<?php
include 'footer.php';
?>