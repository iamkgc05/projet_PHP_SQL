<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();



include 'menu.php';


if (!isset($_GET['id_type'])) {
    header('Location:index.php');
    die;
}

$type_req = $bdd->prepare('SELECT * FROM type WHERE type.id_type = :id');
$type_req->execute(['id' => $_GET['id_type']]);

if ($type_req->rowCount() === 0) {
    header('Location:index.php');
    die;
}

$type = $type_req->fetch();
ob_end_flush();

?>

<section id="fiche_type">
    <div class="container-lg">

        <div class="text-center">

            <h1> Fiche du type </h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">

                <form action="" method="post">
                    <div>
                        <label for="" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" value="<?= $type['nom'] ?>" disabled>
                    </div>

                    <!-- verification admin pour modifier la fiche -->
                    <?php
                    if ($_SESSION['admin'] == 1) {
                        ?>
                        <div>
                            <label for="" class="form-label">Valide</label>
                            <input class="form-control" type="text" name="valide" id="valide" value="<?= $type['valide'] ?>"
                                disabled>
                        </div>
                        <br>
                        <div class="mb-4 text-center">
                            <a href="edit_type.php?id_type=<?= $_GET['id_type'] ?>" class="btn btn-outline-dark"> Modifier
                                la Fiche</a>
                        </div>
                        <?php
                    }
                    ?>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php' ?>