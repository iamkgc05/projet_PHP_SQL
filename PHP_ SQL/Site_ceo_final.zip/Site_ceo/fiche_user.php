<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();


include 'menu.php';



if (!isset($_GET['id_user'])) {
    header('Location:index.php');
    die;
}

$user_req = $bdd->prepare('SELECT * FROM users WHERE users.id_user = :id');
$user_req->execute(['id' => $_GET['id_user']]);
if ($user_req->rowCount() === 0) {
    header('Location:index.php');
    die;
}
$user = $user_req->fetch();
ob_end_flush();

?>



<section id="fiche_user">
    <div class="container-lg">

        <div class="text-center">

            <h1> Fiche de l'utilisateur </h1>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form action="" method="post">
                    <div>
                        <label for="" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" value="<?= $user['nom'] ?>" disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Pseudo</label>
                        <input class="form-control" type="text" name="pseudonyme" value="<?= $user['pseudonyme'] ?>"
                            disabled>
                    </div>

                    <div>
                        <label for="" class="form-label">Nombre de Combat </label>
                        <?php
                        $combat_Rq = $bdd->prepare('SELECT COUNT(*) FROM combat LEFT JOIN users ON combat.id_user_combattant = users.id_user WHERE id_user_combattant = ?');
                        $combat_Rq->execute([$user['id_user']]);
                        $combat = $combat_Rq->fetch();
                        ?>
                        <input class="form-control" type="number" name="combat" value="<?= $combat[0] ?>" disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Admin</label>
                        <input class="form-control" type="number" name="admin" value="<?= $user['admin'] ?>" disabled>
                    </div>
                    <div>
                        <label for="" class="form-label">Ban</label>
                        <input class="form-control" type="number" name="ban" value="<?= $user['ban'] ?>" disabled>
                    </div>
                    <br>
                    <div class="mb-4 text-center">
                        <a href="edit_user.php?id_user=<?= $_GET['id_user'] ?>" class="btn btn-outline-dark"> Modifier
                            la
                            Fiche</a>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php' ?>