<?php

function isUserConnected()
{
    if (!isset($_SESSION['id_user'])) {
        header('Location:connexion.php');
        die;
    }
}
function isAdmin()
{
    if (isset($_SESSION['admin']) && $_SESSION['admin'] == 0) {
        header('Location:index.php');
        die;
    }
}

function isBan()
{
    if (isset($_SESSION['ban']) && $_SESSION['ban'] == 1) {
        header('Location:ban.php');
        die;
    }
}


