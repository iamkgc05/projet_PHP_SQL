<?php
include 'header.php';
include 'function.php';
isUserConnected();
isBan();

header("refresh:3;url=index.php");
?>

<h1>GG mon gars attends je te redirige tout de suite vers mon site</h1>
<?php include 'footer.php' ?>