-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : sam. 23 déc. 2023 à 09:04
-- Version du serveur : 8.0.30
-- Version de PHP : 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gfc_test1`
--

-- --------------------------------------------------------

--
-- Structure de la table `combat`
--

CREATE TABLE `combat` (
  `id_combat` int NOT NULL,
  `id_combattant_combat_1` int DEFAULT NULL,
  `id_combattant_combat_2` int DEFAULT NULL,
  `id_user_combattant` int DEFAULT NULL,
  `id_winner` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `combat`
--

INSERT INTO `combat` (`id_combat`, `id_combattant_combat_1`, `id_combattant_combat_2`, `id_user_combattant`, `id_winner`) VALUES
(4, 1, 3, 9, 1),
(5, 1, 3, 9, 1),
(6, 1, 3, 9, 1),
(7, 4, 5, 9, 4),
(8, 1, 4, 9, 1),
(9, 6, 7, 12, 6),
(10, 4, 6, 12, 4),
(11, 8, 9, 12, 8),
(12, 8, 9, 12, 8),
(13, 8, 7, 12, 8),
(14, 8, 9, 12, 8),
(15, 10, 7, 12, 10);

-- --------------------------------------------------------

--
-- Structure de la table `combattant`
--

CREATE TABLE `combattant` (
  `id_combattant` int NOT NULL,
  `id_personnage_combattant` int DEFAULT NULL,
  `id_equipement_combattant` int DEFAULT NULL,
  `stats_calcule` int DEFAULT NULL,
  `win` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `combattant`
--

INSERT INTO `combattant` (`id_combattant`, `id_personnage_combattant`, `id_equipement_combattant`, `stats_calcule`, `win`) VALUES
(1, 1, 1, 1000999, 10),
(3, 2, 1, 1000, 0),
(4, 1, 2, 999999, 2),
(5, 2, 1, 1, 0),
(6, 8, 1, 1020, 4),
(7, 2, 1, 1001, 0),
(8, 1, 1, 10000, 14),
(9, 2, 2, 1, 0),
(10, 1, 2, 9000, 1);

-- --------------------------------------------------------

--
-- Structure de la table `equipement`
--

CREATE TABLE `equipement` (
  `id_equipement` int NOT NULL,
  `nom_equipement` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bonus` int DEFAULT NULL,
  `id_type_equipement` int DEFAULT NULL,
  `profil` varchar(255) DEFAULT NULL,
  `valide` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `equipement`
--

INSERT INTO `equipement` (`id_equipement`, `nom_equipement`, `bonus`, `id_type_equipement`, `profil`, `valide`) VALUES
(1, 'Bracelet de creation Universelle', 1000, 1, NULL, 0),
(2, 'Infinity Gantlet', 1000, 2, 'images/', 0),
(3, 'Dragon Claw', 20, 1, 'images/', 1);

-- --------------------------------------------------------

--
-- Structure de la table `personnage`
--

CREATE TABLE `personnage` (
  `id_personnage` int NOT NULL,
  `nom_personnage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `stats` int NOT NULL,
  `id_type_personnage` int NOT NULL,
  `profil` varchar(255) DEFAULT NULL,
  `description` text,
  `valide` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `personnage`
--

INSERT INTO `personnage` (`id_personnage`, `nom_personnage`, `stats`, `id_type_personnage`, `profil`, `description`, `valide`) VALUES
(1, 'Carlos', 9000, 1, NULL, 'Le meilleur du monde v2v', 0),
(2, 'Yuna', 1, 1, NULL, 'ok', 0),
(6, 'TEST', 40, 2, 'images/tauros.jpg', 'TEST D4IMPORT', 1),
(7, 'Rhade', 25, 1, 'images/bongo.jpeg', 'Rhade, préfère que l&#039;on l&#039;appelle Rhadé;', 1),
(8, 'test_final', 20, 1, 'images/Capture d\'écran 2023-12-21 211631.png', 'c\'est mon test final et ça me parait pas mal', 0),
(9, 'libolo', 13, 1, 'images/', '', 1),
(10, 'libolo', 13, 1, 'images/', '', 1),
(11, 'eminence', 8, 3, 'images/', '', 1);

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE `type` (
  `id_type` int NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `valide` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `type`
--

INSERT INTO `type` (`id_type`, `nom`, `valide`) VALUES
(1, 'Fire', 0),
(2, 'Water', 0),
(3, 'Grass', 0);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id_user` int NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pseudonyme` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `mots_de_passe` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `adresse_mail` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `ban` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id_user`, `nom`, `pseudonyme`, `mots_de_passe`, `adresse_mail`, `admin`, `ban`) VALUES
(1, 'Carlos', 'Master', 'mdp', 'okindaceo@gmail.com', 1, 0),
(2, 'Carlito', 'user_test', '00d70c561892a94980befd12a400e26aeb4b8599', 'draco@gmail.com', 1, 0),
(8, 'dd', 'dd', '388ad1c312a488ee9e12998fe097f2258fa8d5ee', 'dd@dd.com', 0, 1),
(9, 'd2', 'd2', 'ce9ed66d82df7ce028a8623498350e2fb4412132', 'd2@gmail.com', 0, 0),
(10, 'Okindad', 'ceodad', '7a85f4764bbd6daf1c3545efbbf0f279a6dc0beb', 'greycekinda@gmail.com', 0, 0),
(11, 'stiev', 'emmaaa', '6057273562eab3e87b135bae42019558d68454e5', 'greycekinda@gmail.com', 0, 0),
(12, 'admin1', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Alysonokinda@gmail.com', 1, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `combat`
--
ALTER TABLE `combat`
  ADD PRIMARY KEY (`id_combat`),
  ADD KEY `id_combattant_combat_1` (`id_combattant_combat_1`),
  ADD KEY `id_combattant_combat_2` (`id_combattant_combat_2`),
  ADD KEY `id_user_combattant` (`id_user_combattant`),
  ADD KEY `id_winner` (`id_winner`);

--
-- Index pour la table `combattant`
--
ALTER TABLE `combattant`
  ADD PRIMARY KEY (`id_combattant`),
  ADD KEY `id_personnage_combattant` (`id_personnage_combattant`),
  ADD KEY `id_equipement_combattant` (`id_equipement_combattant`);

--
-- Index pour la table `equipement`
--
ALTER TABLE `equipement`
  ADD PRIMARY KEY (`id_equipement`),
  ADD KEY `id_type_equipement` (`id_type_equipement`);

--
-- Index pour la table `personnage`
--
ALTER TABLE `personnage`
  ADD PRIMARY KEY (`id_personnage`),
  ADD KEY `id_type_personnage` (`id_type_personnage`);

--
-- Index pour la table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id_type`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `combat`
--
ALTER TABLE `combat`
  MODIFY `id_combat` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `combattant`
--
ALTER TABLE `combattant`
  MODIFY `id_combattant` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `equipement`
--
ALTER TABLE `equipement`
  MODIFY `id_equipement` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `personnage`
--
ALTER TABLE `personnage`
  MODIFY `id_personnage` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `type`
--
ALTER TABLE `type`
  MODIFY `id_type` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `combat`
--
ALTER TABLE `combat`
  ADD CONSTRAINT `combat_ibfk_1` FOREIGN KEY (`id_combattant_combat_1`) REFERENCES `combattant` (`id_combattant`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `combat_ibfk_2` FOREIGN KEY (`id_combattant_combat_2`) REFERENCES `combattant` (`id_combattant`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `combat_ibfk_3` FOREIGN KEY (`id_user_combattant`) REFERENCES `users` (`id_user`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `combat_ibfk_4` FOREIGN KEY (`id_winner`) REFERENCES `combattant` (`id_combattant`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Contraintes pour la table `combattant`
--
ALTER TABLE `combattant`
  ADD CONSTRAINT `combattant_ibfk_1` FOREIGN KEY (`id_personnage_combattant`) REFERENCES `personnage` (`id_personnage`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `combattant_ibfk_2` FOREIGN KEY (`id_equipement_combattant`) REFERENCES `equipement` (`id_equipement`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Contraintes pour la table `equipement`
--
ALTER TABLE `equipement`
  ADD CONSTRAINT `equipement_ibfk_1` FOREIGN KEY (`id_type_equipement`) REFERENCES `type` (`id_type`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Contraintes pour la table `personnage`
--
ALTER TABLE `personnage`
  ADD CONSTRAINT `personnage_ibfk_1` FOREIGN KEY (`id_type_personnage`) REFERENCES `type` (`id_type`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
