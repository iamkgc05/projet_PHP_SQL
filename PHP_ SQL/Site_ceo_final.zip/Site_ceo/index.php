<?php
include 'header.php';
ob_start();

include 'function.php';
isUserConnected();
isBan();

include 'menu.php';

ob_end_flush();


$persos_req = $bdd->query('SELECT * FROM personnage WHERE personnage.valide = 0 ORDER BY stats DESC LIMIT 10');
$persos = $persos_req->fetchAll();
?>


<h1>Les meilleurs combattants</h1>
<table class="table">
    <thead>
        <tr>

            <th>Nom</th>
            <th>Stats</th>
            <th> Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($persos as $perso) {
            ?>
            <tr>
                <td>
                    <?= $perso['nom_personnage'] ?>
                </td>
                <td>
                    <?= $perso['stats'] ?>
                </td>
                <td>
                    <a href="fiche.php?id_personnage=<?php echo $perso['id_personnage']; ?>">
                        Detail du personnage
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
    </tbody>

</table>

<h1> L'historique des combats </h1>
<table class="table">
    <thead>
        <tr>
            <th>Combattant 1</th>
            <th>Combattant 2</th>
            <th>Gagant</th>
            <th>Realise par</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $combats_req = $bdd->query('SELECT * FROM combat ORDER BY id_combat DESC LIMIT 10');
        $combats = $combats_req->fetchAll();
        foreach ($combats as $combat) {
            ?>
            <tr>
                <td>
                    <?php
                    $combattant1_req = $bdd->prepare('SELECT * FROM combattant WHERE id_combattant = ?');
                    $combattant1_req->execute([$combat['id_combattant_combat_1']]);
                    $combattant1 = $combattant1_req->fetch();

                    $perso1_req = $bdd->prepare('SELECT * FROM personnage WHERE id_personnage = ?');
                    $perso1_req->execute([$combattant1['id_personnage_combattant']]);
                    $perso1 = $perso1_req->fetch();
                    ?>
                    <?= $perso1['nom_personnage'] ?>
                </td>
                <td>
                    <?php
                    $combattant2_req = $bdd->prepare('SELECT * FROM combattant WHERE id_combattant = ?');
                    $combattant2_req->execute([$combat['id_combattant_combat_2']]);
                    $combattant2 = $combattant2_req->fetch();

                    $perso2_req = $bdd->prepare('SELECT * FROM personnage WHERE id_personnage = ?');
                    $perso2_req->execute([$combattant2['id_personnage_combattant']]);
                    $perso2 = $perso2_req->fetch();
                    ?>
                    <?= $perso2['nom_personnage'] ?>
                </td>
                <td>
                    <?php
                    $gagnant_req = $bdd->prepare('SELECT * FROM combattant WHERE id_combattant = ?');
                    $gagnant_req->execute([$combat['id_winner']]);
                    $gagnant = $gagnant_req->fetch();

                    $perso_gagnant_req = $bdd->prepare('SELECT * FROM personnage WHERE id_personnage = ?');
                    $perso_gagnant_req->execute([$gagnant['id_personnage_combattant']]);
                    $perso_gagnant = $perso_gagnant_req->fetch();
                    ?>
                    <?= $perso_gagnant['nom_personnage'] ?>
                </td>
                <td>
                    <?php
                    $user_req = $bdd->prepare('SELECT * FROM users WHERE id_user = ?');
                    $user_req->execute([$combat['id_user_combattant']]);
                    $user = $user_req->fetch();
                    ?>
                    <?= $user['pseudonyme'] ?>
                </td>

                <!-- Pour une future mise-a-jour j'ai pense a pouvoir voir les details d'un combat, càd les personnages ET leurs equipements ainsi que le stats-->

                <?php
        }
        ?>
    </tbody>


    <?php include 'footer.php' ?>