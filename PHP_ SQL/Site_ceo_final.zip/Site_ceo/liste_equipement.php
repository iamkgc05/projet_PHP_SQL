<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();



include 'menu.php';

ob_end_flush();

// Si c'est un admin il peut voir tous les equipements
if ($_SESSION['admin'] == 1) {
    $equipement_req = $bdd->query('SELECT * FROM equipement');
    $equipement = $equipement_req->fetchAll();

    // Sinon il ne peut voir que les equipements validés
} else {
    $equipement_req = $bdd->query('SELECT * FROM equipement WHERE valide = 0');
    $equipement = $equipement_req->fetchAll();
}
?>

<h1> Liste des equipements </h1>
<table class="table">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Bonus</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($equipement as $equipement) {
            ?>
            <tr>
                <td>
                    <?= $equipement['nom_equipement'] ?>
                </td>
                <td>
                    <?= $equipement['bonus'] ?>
                </td>
                <td>
                    <a href="fiche_equipement.php?id_equipement=<?php echo $equipement['id_equipement']; ?>">
                        Detail de l'equipement
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
    </tbody>