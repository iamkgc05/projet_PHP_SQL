<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();



include 'menu.php';

ob_end_flush();

// Si c'est un admin il peut voir tous les personnages
if ($_SESSION['admin'] == 1) {
    $perso_req = $bdd->query('SELECT * FROM personnage');
    $perso = $perso_req->fetchAll();

    // Sinon il ne peut voir que les personnages validés
} else {
    $perso_req = $bdd->query('SELECT * FROM personnage WHERE valide = 0');
    $perso = $perso_req->fetchAll();
}


?>

<h1> Liste des personnages </h1>

<table class="table">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Stats</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($perso as $perso) {
            ?>
            <tr>
                <td>
                    <?= $perso['nom_personnage'] ?>
                </td>
                <td>
                    <?= $perso['stats'] ?>
                </td>
                <td>
                    <a href="fiche.php?id_personnage=<?php echo $perso['id_personnage']; ?>">
                        Detail du personnage
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
    </tbody>
</table>

<?php
include 'footer.php';
?>