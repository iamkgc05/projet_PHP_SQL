<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();



include 'menu.php';

ob_end_flush();
// Si c'est un admin il peut voir tous les types
if ($_SESSION['admin'] == 1) {
    $type_req = $bdd->query('SELECT * FROM type');
    $type = $type_req->fetchAll();

    // Sinon il ne peut voir que les types validés
} else {
    $type_req = $bdd->query('SELECT * FROM type WHERE valide = 0');
    $type = $type_req->fetchAll();
}
?>

<h1> Liste des types </h1>
<table class="table">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($type as $type) {
            ?>
            <tr>
                <td>
                    <?= $type['nom'] ?>
                </td>
                <td>
                    <a href="fiche_type.php?id_type=<?php echo $type['id_type']; ?>">
                        Detail du type
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
    </tbody>
</table>

<?php
include 'footer.php';
?>