<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php"><i class="bi bi-trophy-fill"></i>Global Fighting Cup</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="fiche_user.php?id_user=<?= $_SESSION['id_user']; ?>">
                    Votre fiche
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="combat.php">Faire un combat</a>
            </li>
            <li class="nav-item dropdown">
                <div class="dropdown">
                    <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton1"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Personnages
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="liste_perso.php">Listes des personnages</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="create.php">Creer un Nouveau Personnage</a></li>
                    </ul>
                </div>
            </li>
            <li class="nav-item dropdown">
                <div class="dropdown">
                    <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton2"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Equipement
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
                        <li><a class="dropdown-item" href="liste_equipement.php">Listes des Equipements</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="create_equipement.php">Creer un Nouveau equipement</a></li>
                    </ul>
                </div>
            </li>
            <li class="nav-item dropdown">
                <div class="dropdown">
                    <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton3"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Types
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton3">
                        <li><a class="dropdown-item" href="liste_type.php">Listes des Types</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="create_type.php">Creer un Nouveau Type</a></li>
                    </ul>
                </div>
            </li>
            <?php
            if ($_SESSION['admin'] == 1) { //la page admin n'est accessible que par les admins
                ?>
                <li class="nav-item">
                    <a class="nav-link" href="admin.php">Page Admin</a>
                </li>
                <?php
            }
            ?>

            <li class="nav-item ">
                <a class="nav-link" href="deconnexion.php">Se Deconnecter</a>
            </li>
        </ul>
    </div>
</nav>