<?php
include 'header.php';
include 'function.php';
isUserConnected();
isBan();

header("refresh:3;url=index.php");
?>

<h1>Bonjour monsieur le perdant je te laisse aller sur mon site pour une fois</h1>

<?php
include "footer.php"
    ?>