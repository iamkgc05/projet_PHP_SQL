<?php
include 'header.php';

if (isset($_POST["envoi"])) {
    if ($_POST["mots_de_passe"] == $_POST["mots_de_passe2"]) {
        $pseudo = htmlspecialchars($_POST["Pseudonyme"]);
        $nom = htmlspecialchars($_POST["nom"]);
        $email = htmlspecialchars($_POST["email"]);
        $mdp = sha1($_POST["mots_de_passe"]);

        $insert_user = $bdd->prepare("INSERT INTO users( nom,pseudonyme, adresse_mail, mots_de_passe) VALUES(?,?,?,?)");
        $insert_user->execute(array($nom, $pseudo, $email, $mdp));

        $recup_user = $bdd->prepare("SELECT * FROM users WHERE pseudonyme = ? AND mots_de_passe = ?");
        $recup_user->execute(array($pseudo, $mdp));
        if ($recup_user->rowCount() > 0) {
            $user_info = $recup_user->fetch();
            $_SESSION['id_user'] = $user_info['id_user'];
            $_SESSION['pseudonyme'] = $pseudo;
            $_SESSION['mots_de_passe'] = $mdp;
            $_SESSION['email'] = $email;
            $_SESSION['admin'] = $user_info['admin'];
            $_SESSION['ban'] = $user_info['ban'];
            header('Location: connexion.php');
        }

    } else {
        echo "Les mots de passe ne sont pas identiques, ou il manque des informations";
    }
}

?>

<section id="signup">
    <div class="container-lg">
        <div class="text-center">
            <h2> Creer un compte</h2>
            <p class="lead">Vos données ne seront jamais partagées</p>
        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-6">
                <form action="" method="POST">
                    <div>
                        <label for="nom" class="form-label">Nom</label>
                        <input class="form-control" type="text" name="nom" id="nom" required>
                    </div>
                    <div>
                        <label for="pseudo" class="form-label">Pseudonyme</label>
                        <input class="form-control" type="text" name="Pseudonyme" id="pseudo" required>
                    </div>
                    <div>
                        <label for="E-mail" class="form-label">E-mail</label>
                        <input class="form-control" type="email" name="email" id="email" required>
                    </div>
                    <div>
                        <label for="mot_de_passe" class="form-label">Mot de passe</label>
                        <input class="form-control" type="password" name="mots_de_passe" id="mdp1" required>
                    </div>
                    <div>
                        <label for="mot_de_passe2" class="form-label">Valide ton mots_de_passe</label>
                        <input class="form-control" type="password" name="mots_de_passe2" id="mdp2" required>
                    </div>
                    <br>
                    <div class="mb-4 text-center">
                        <input class="btn btn-outline-dark" type="submit" name="envoi" value="S'inscrire">
                    </div>
                    <div class="mb-4 text-center">
                        <a href="connexion.php">Déjà un compte? Connecte-toi</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>


<?php include 'footer.php' ?>