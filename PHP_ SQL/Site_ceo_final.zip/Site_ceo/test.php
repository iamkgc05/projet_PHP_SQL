<?php
include 'header.php';
include 'function.php';

isUserConnected();
isBan();

if (isset($_POST['devinette'])) {
    $mot = "poulet";
    if (!isset($_SESSION['tentatives'])) {
        $_SESSION['tentatives'] = 1;
    }

    if ($_POST['devinette'] == $mot && $_SESSION['tentatives'] < 5) {
        echo "Bravo tu as trouvé le mot";
        unset($_SESSION['tentatives']);
        header('Location: gagner.php');
        die;
    } else if ($_POST['devinette'] != $mot && $_SESSION['tentatives'] < 5) {
        echo "Ce n'est pas le bon mot";
        $_SESSION['tentatives'] += 1;

    } else if ($_SESSION['tentatives'] == 5) {
        header('Location: perdu.php');
        unset($_SESSION['tentatives']);
        die;
    }
}


?>
<!-- petit test pour deviner le mot -->



<section id="test">
    <div class="container-lg">

        <div class="text-center">
            <h1> Voici un petit test essaye de deviner le mot</h1>
            <p class="lead">... Si vous trouvez le mot vous me connaissez très bien ou bien c'est juste un stéréotype
            </p>
            <p class="lead">ou bien vous avez une très bonne vue</p>
            <p class="lead">Au bout de 5 tentative vous allez être rediriger Bonne chance </p>

        </div>
        <div class="row justify-content-center my-5">
            <div class="col-lg-4">
                <form action="" method="POST">
                    <div>
                        <label for="mot" class="form-label">Mot ? </label>
                        <input type="password" name="devinette" class="form-control" autocomplete="off" required>
                    </div>
                    <br>
                    <div class="mb-4 text-center">
                        <input class="btn btn-outline-dark" type="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<!-- Un petit easter egg pour skip le test-->
<div class="mb-4 text-center">
    <a href="gagner.php"><button class="btn btn-outline-light">.</button></a>
</div>
<?php include 'footer.php' ?>