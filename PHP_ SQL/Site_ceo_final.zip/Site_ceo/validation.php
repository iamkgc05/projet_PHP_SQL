<?php
include 'header.php';

ob_start();

include 'function.php';
isUserConnected();
isBan();



include 'menu.php';

ob_end_flush();

header('refresh:5;url=index.php');
?>


<h1>
    Votre demande a bien été prise en compte, elle sera validé par un administrateur dans les meilleurs délais
</h1>

<?php include 'footer.php' ?>