<?php
include 'header.php';



include 'function.php';
isUserConnected();
isBan();




$insert_result = $bdd->prepare('SELECT * FROM combattant WHERE id_personnage_combattant = :id_personnage AND id_equipement_combattant = :id_equipement AND stats_calcule = :stats_calcule');
$insert_result->execute(array(
    'id_personnage' => $_SESSION['id_winner'],
    'id_equipement' => $_SESSION['id_equipement_winner'],
    'stats_calcule' => $_SESSION['stats_winner']
));

if ($insert_result->rowCount() == 0) {
    $insert_new = $bdd->prepare('INSERT INTO combattant(id_personnage_combattant, id_equipement_combattant, stats_calcule, win) VALUES(:id_personnage, :id_equipement, :stats_calcule, :win)');
    $insert_new->execute(
        array(
            'id_personnage' => $_SESSION['id_winner'],
            'id_equipement' => $_SESSION['id_equipement_winner'],
            'stats_calcule' => $_SESSION['stats_winner'],
            'win' => 1
        )
    );

    // selection de l'id du combattant
    $id_combattant_winner = $bdd->lastInsertId();

} else {
    $update = $bdd->prepare('UPDATE combattant SET win = win + 1 WHERE id_personnage_combattant = :id_personnage AND id_equipement_combattant = :id_equipement AND stats_calcule = :stats_calcule');
    $update->execute(
        array(
            'id_personnage' => $_SESSION['id_winner'],
            'id_equipement' => $_SESSION['id_equipement_winner'],
            'stats_calcule' => $_SESSION['stats_winner']
        )
    );

    $id_combattant_winner = $insert_result->fetch()['id_combattant'];

}
// insertion du perdant

$insert_result2 = $bdd->prepare('SELECT * FROM combattant WHERE id_personnage_combattant = :id_personnage AND id_equipement_combattant = :id_equipement AND stats_calcule = :stats_calcule');
$insert_result2->execute(array(
    'id_personnage' => $_SESSION['id_looser'],
    'id_equipement' => $_SESSION['id_equipement_looser'],
    'stats_calcule' => $_SESSION['stats_looser']
));
if ($insert_result2->rowCount() == 0) {
    $insert_new2 = $bdd->prepare('INSERT INTO combattant(id_personnage_combattant, id_equipement_combattant, stats_calcule, win) VALUES(:id_personnage, :id_equipement, :stats_calcule, :win)');
    $insert_new2->execute(
        array(
            'id_personnage' => $_SESSION['id_looser'],
            'id_equipement' => $_SESSION['id_equipement_looser'],
            'stats_calcule' => $_SESSION['stats_looser'],
            'win' => 0
        )
    );

    $id_combattant_looser = $bdd->lastInsertId();
} else {
    $id_combattant_looser = $insert_result2->fetch()['id_combattant'];
}
;

// combat fait 

//id_combat	id_combattant_combat_1	id_combattant_combat_2		id_winner 
/*
$verif_combat = $bdd->prepare('SELECT * FROM combat WHERE id_combattant_combat_1 = :id_combattant_combat_1 AND id_combattant_combat_2 = :id_combattant_combat_2 AND id_winner = :id_winner AND id_user_combattant = :id_user_combattant');
$verif_combat->execute(
    array(
        'id_combattant_combat_1' => $id_combattant_winner,
        'id_combattant_combat_2' => $id_combattant_looser,
        'id_winner' => $id_combattant_winner,
        'id_user_combattant' => $_SESSION['id_user']
    )
);
if ($verif_combat->rowCount() != 0) {
    echo "Vous avez déjà fait ce combat";
    header("refresh:3;url=combat.php");
    die;
} else {
*/
$insert_combat = $bdd->prepare('INSERT INTO combat(id_combattant_combat_1, id_combattant_combat_2, id_user_combattant, id_winner) VALUES(:id_combattant_combat_1, :id_combattant_combat_2, :id_user_combattant, :id_winner)');
$insert_combat->execute(
    array(
        'id_combattant_combat_1' => $id_combattant_winner,
        'id_combattant_combat_2' => $id_combattant_looser,
        'id_user_combattant' => $_SESSION['id_user'],
        'id_winner' => $id_combattant_winner
    )
);

header("refresh:3;url=combat.php");
//}
?>

<h1>Le perso 2 à gagner son compteur de victoires est mis a jour</h1>

<?php include 'footer.php' ?>